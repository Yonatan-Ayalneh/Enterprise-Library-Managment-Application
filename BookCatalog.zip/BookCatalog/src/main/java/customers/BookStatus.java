package customers;

public enum BookStatus {
    AVAILABLE, BORROWED, RESERVED
}
