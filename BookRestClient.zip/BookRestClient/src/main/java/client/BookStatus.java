package client;

public enum BookStatus {
    AVAILABLE, BORROWED, RESERVED
}
