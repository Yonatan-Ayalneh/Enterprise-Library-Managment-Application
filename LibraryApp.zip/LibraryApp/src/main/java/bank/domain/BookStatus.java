package bank.domain;

public enum BookStatus {
    AVAILABLE, BORROWED, RESERVED
}
